package com.g.music;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class Music extends Activity {
	public MediaPlayer Play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mactivity_main);
        
        Button btnStart=(Button) findViewById(R.id.button1);
        Button btnStop=(Button) findViewById(R.id.button2);
        
        btnStart.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
			Oncreate();}
		});
btnStop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
			ondestroy();}
		});
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.music, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void Oncreate(){
    	
    	Toast.makeText(this,"music played",Toast.LENGTH_SHORT).show();
    	Play=MediaPlayer.create(this,R.raw.p);
    	Play.setLooping(false);
    	Play.start();
    	
    }
    
    public void ondestroy(){
    	Toast.makeText(this, "music Stoped", Toast.LENGTH_LONG).show();
    	Play.stop();
    }
}
